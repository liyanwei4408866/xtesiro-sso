package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsAccessControlRecord;

public interface LrmsAccessControlRecordMapper {
    int insert(LrmsAccessControlRecord record);

    int insertSelective(LrmsAccessControlRecord record);
}