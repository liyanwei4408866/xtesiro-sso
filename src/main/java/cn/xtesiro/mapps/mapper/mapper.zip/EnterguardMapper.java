package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.Enterguard;

public interface EnterguardMapper {
    int insert(Enterguard record);

    int insertSelective(Enterguard record);
}