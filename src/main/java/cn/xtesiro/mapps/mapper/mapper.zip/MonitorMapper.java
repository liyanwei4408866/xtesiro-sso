package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.Monitor;

public interface MonitorMapper {
    int insert(Monitor record);

    int insertSelective(Monitor record);
}