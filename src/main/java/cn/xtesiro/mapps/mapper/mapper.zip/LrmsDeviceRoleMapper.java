package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsDeviceRole;

public interface LrmsDeviceRoleMapper {
    int insert(LrmsDeviceRole record);

    int insertSelective(LrmsDeviceRole record);
}