package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsIncomemail;

public interface LrmsIncomemailMapper {
    int insert(LrmsIncomemail record);

    int insertSelective(LrmsIncomemail record);
}