package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsInstrument;

public interface LrmsInstrumentMapper {
    int insert(LrmsInstrument record);

    int insertSelective(LrmsInstrument record);
}