package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsLetter;

public interface LrmsLetterMapper {
    int insert(LrmsLetter record);

    int insertSelective(LrmsLetter record);
}