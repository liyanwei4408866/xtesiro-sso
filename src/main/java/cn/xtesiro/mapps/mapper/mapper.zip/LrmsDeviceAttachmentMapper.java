package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsDeviceAttachment;

public interface LrmsDeviceAttachmentMapper {
    int insert(LrmsDeviceAttachment record);

    int insertSelective(LrmsDeviceAttachment record);
}