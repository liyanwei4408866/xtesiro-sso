package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.ProjectMember;

public interface ProjectMemberMapper {
    int insert(ProjectMember record);

    int insertSelective(ProjectMember record);
}