package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsSettlement;

public interface LrmsSettlementMapper {
    int insert(LrmsSettlement record);

    int insertSelective(LrmsSettlement record);
}