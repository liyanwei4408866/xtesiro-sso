package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsInstrumentcharges;

public interface LrmsInstrumentchargesMapper {
    int insert(LrmsInstrumentcharges record);

    int insertSelective(LrmsInstrumentcharges record);
}