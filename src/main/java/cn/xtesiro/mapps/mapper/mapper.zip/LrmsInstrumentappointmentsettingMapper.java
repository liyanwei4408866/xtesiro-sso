package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsInstrumentappointmentsettingWithBLOBs;

public interface LrmsInstrumentappointmentsettingMapper {
    int insert(LrmsInstrumentappointmentsettingWithBLOBs record);

    int insertSelective(LrmsInstrumentappointmentsettingWithBLOBs record);
}