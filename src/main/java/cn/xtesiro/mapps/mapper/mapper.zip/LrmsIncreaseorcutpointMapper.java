package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsIncreaseorcutpoint;

public interface LrmsIncreaseorcutpointMapper {
    int insert(LrmsIncreaseorcutpoint record);

    int insertSelective(LrmsIncreaseorcutpoint record);
}