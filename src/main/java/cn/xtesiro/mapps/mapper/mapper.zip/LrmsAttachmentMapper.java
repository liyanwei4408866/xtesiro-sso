package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsAttachment;

public interface LrmsAttachmentMapper {
    int insert(LrmsAttachment record);

    int insertSelective(LrmsAttachment record);
}