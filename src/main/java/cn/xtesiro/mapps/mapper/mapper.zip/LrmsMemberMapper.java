package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsMember;

public interface LrmsMemberMapper {
    int insert(LrmsMember record);

    int insertSelective(LrmsMember record);
}