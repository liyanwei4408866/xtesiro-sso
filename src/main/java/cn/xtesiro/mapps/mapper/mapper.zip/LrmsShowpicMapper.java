package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsShowpic;

public interface LrmsShowpicMapper {
    int insert(LrmsShowpic record);

    int insertSelective(LrmsShowpic record);
}