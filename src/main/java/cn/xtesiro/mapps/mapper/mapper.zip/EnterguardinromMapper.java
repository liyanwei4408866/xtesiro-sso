package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.Enterguardinrom;

public interface EnterguardinromMapper {
    int insert(Enterguardinrom record);

    int insertSelective(Enterguardinrom record);
}