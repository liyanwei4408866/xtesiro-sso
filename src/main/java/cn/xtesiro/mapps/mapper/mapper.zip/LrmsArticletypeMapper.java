package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsArticletype;

public interface LrmsArticletypeMapper {
    int insert(LrmsArticletype record);

    int insertSelective(LrmsArticletype record);
}