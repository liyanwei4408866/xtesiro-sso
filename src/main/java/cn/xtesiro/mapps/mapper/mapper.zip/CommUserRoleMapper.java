package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.common.entity.CommUserRole;
import cn.xtesiro.mapps.common.mybatis.IBaseDao;

public interface CommUserRoleMapper extends IBaseDao<CommUserRole> {
}