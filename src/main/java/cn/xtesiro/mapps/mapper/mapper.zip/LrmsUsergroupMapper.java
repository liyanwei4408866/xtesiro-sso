package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsUsergroup;

public interface LrmsUsergroupMapper {
    int insert(LrmsUsergroup record);

    int insertSelective(LrmsUsergroup record);
}