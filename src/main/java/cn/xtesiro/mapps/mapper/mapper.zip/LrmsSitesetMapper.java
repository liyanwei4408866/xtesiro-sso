package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsSiteset;

public interface LrmsSitesetMapper {
    int insert(LrmsSiteset record);

    int insertSelective(LrmsSiteset record);
}