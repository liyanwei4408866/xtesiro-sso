package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsArticle;

public interface LrmsArticleMapper {
    int insert(LrmsArticle record);

    int insertSelective(LrmsArticle record);
}