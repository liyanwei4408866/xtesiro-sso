package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.common.entity.CommUsergrpRole;
import cn.xtesiro.mapps.common.mybatis.IBaseDao;

public interface CommUsergrpRoleMapper extends IBaseDao<CommUsergrpRole> {
//    int insert(CommUsergrpRole record);
//
//    int insertSelective(CommUsergrpRole record);
}