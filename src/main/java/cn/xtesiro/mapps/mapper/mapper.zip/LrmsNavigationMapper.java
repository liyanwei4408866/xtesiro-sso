package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsNavigation;

public interface LrmsNavigationMapper {
    int insert(LrmsNavigation record);

    int insertSelective(LrmsNavigation record);
}