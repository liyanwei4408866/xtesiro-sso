package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsLink;

public interface LrmsLinkMapper {
    int insert(LrmsLink record);

    int insertSelective(LrmsLink record);
}