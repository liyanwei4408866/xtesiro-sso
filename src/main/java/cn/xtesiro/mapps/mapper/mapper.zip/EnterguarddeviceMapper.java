package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.Enterguarddevice;

public interface EnterguarddeviceMapper {
    int insert(Enterguarddevice record);

    int insertSelective(Enterguarddevice record);
}