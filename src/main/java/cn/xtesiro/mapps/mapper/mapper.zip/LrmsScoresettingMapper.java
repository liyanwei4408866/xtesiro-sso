package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsScoresetting;

public interface LrmsScoresettingMapper {
    int insert(LrmsScoresetting record);

    int insertSelective(LrmsScoresetting record);
}