package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.Dbbackup;

public interface DbbackupMapper {
    int insert(Dbbackup record);

    int insertSelective(Dbbackup record);
}