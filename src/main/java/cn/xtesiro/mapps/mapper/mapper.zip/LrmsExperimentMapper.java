package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsExperiment;

public interface LrmsExperimentMapper {
    int insert(LrmsExperiment record);

    int insertSelective(LrmsExperiment record);
}