package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsResearvationinstrument;

public interface LrmsResearvationinstrumentMapper {
    int insert(LrmsResearvationinstrument record);

    int insertSelective(LrmsResearvationinstrument record);
}