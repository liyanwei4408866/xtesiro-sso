package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsQuestion;

public interface LrmsQuestionMapper {
    int insert(LrmsQuestion record);

    int insertSelective(LrmsQuestion record);
}