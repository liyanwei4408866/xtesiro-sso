package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsMessageWithBLOBs;

public interface LrmsMessageMapper {
    int insert(LrmsMessageWithBLOBs record);

    int insertSelective(LrmsMessageWithBLOBs record);
}