package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsRegistrationinfo;

public interface LrmsRegistrationinfoMapper {
    int insert(LrmsRegistrationinfo record);

    int insertSelective(LrmsRegistrationinfo record);
}