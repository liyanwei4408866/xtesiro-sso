package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsLetterattachment;

public interface LrmsLetterattachmentMapper {
    int insert(LrmsLetterattachment record);

    int insertSelective(LrmsLetterattachment record);
}