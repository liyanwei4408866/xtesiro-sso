package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.Student;

public interface StudentMapper {
    int insert(Student record);

    int insertSelective(Student record);
}