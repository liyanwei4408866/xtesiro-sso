package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.Project;

public interface ProjectMapper {
    int insert(Project record);

    int insertSelective(Project record);
}