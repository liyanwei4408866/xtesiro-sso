package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.common.entity.CommRescRole;
import cn.xtesiro.mapps.common.mybatis.IBaseDao;

public interface CommRescRoleMapper extends IBaseDao<CommRescRole> {
//    int insert(CommRescRole record);
//
//    int insertSelective(CommRescRole record);
}