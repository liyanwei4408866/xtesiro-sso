package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsErreportWithBLOBs;

public interface LrmsErreportMapper {
    int insert(LrmsErreportWithBLOBs record);

    int insertSelective(LrmsErreportWithBLOBs record);
}