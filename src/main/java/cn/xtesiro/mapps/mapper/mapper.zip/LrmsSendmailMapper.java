package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsSendmail;

public interface LrmsSendmailMapper {
    int insert(LrmsSendmail record);

    int insertSelective(LrmsSendmail record);
}