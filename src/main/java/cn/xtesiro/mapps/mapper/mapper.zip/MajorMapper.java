package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.Major;

public interface MajorMapper {
    int insert(Major record);

    int insertSelective(Major record);
}