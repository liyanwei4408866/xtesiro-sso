package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsLab;

public interface LrmsLabMapper {
    int insert(LrmsLab record);

    int insertSelective(LrmsLab record);
}