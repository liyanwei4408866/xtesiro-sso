package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.SubscribeDevice;

public interface SubscribeDeviceMapper {
    int insert(SubscribeDevice record);

    int insertSelective(SubscribeDevice record);
}