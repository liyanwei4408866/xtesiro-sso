package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.Accesslog;

public interface AccesslogMapper {
    int insert(Accesslog record);

    int insertSelective(Accesslog record);
}