package cn.xtesiro.mapps.mapper;

import cn.xtesiro.mapps.entity.LrmsInstrumentreservationWithBLOBs;

public interface LrmsInstrumentreservationMapper {
    int insert(LrmsInstrumentreservationWithBLOBs record);

    int insertSelective(LrmsInstrumentreservationWithBLOBs record);
}