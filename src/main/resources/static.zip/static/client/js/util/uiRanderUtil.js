define(["underscore"], 
	function(_){
		var _uiRanderUtilInstances = {};
		var UiRanderUtil = {};
		UiRanderUtil.randerIcheckbox = function(view){
		};
		UiRanderUtil.randerJQueryUI_Sortable = function(view){
		};	
		return UiRanderUtil;
});