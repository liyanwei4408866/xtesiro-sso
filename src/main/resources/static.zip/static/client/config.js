//window.serviceUrl = "http://miap.cc:9100/mrtest/api";
window.serviceUrl = "http://miap.cc:8565/api";
